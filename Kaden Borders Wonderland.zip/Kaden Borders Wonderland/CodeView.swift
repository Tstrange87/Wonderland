//
//  CodeView.swift
//  Kaden Borders Wonderland
//
//  Created by Kaden Borders on 7/29/25.
//

import SwiftUI

struct CodeView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    CodeView()
}
