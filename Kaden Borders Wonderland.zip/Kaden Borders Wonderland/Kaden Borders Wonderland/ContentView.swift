//
//  ContentView.swift
//  Kaden Borders Wonderland
//
//  Created by Kaden Borders on 7/14/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationStack {
            
            
            ZStack {
                Color.indigo.edgesIgnoringSafeArea(.all)
                
                VStack {
                    Image(systemName: "signature")
                        .imageScale(.large)
                        .foregroundStyle(.tint)
                    Text("Welcome to Kaden Borders's wonderland")
                    
                    Image("Braids")
                        .resizable()
                        .scaledToFit()
                      ZStack {
                        Rectangle()
                              .fill(Color.orange)
                              .frame(width:75, height: 40)
                          NavigationLink("Continue") {
                              NewView()
                          }
                      }
                    
                }
                .padding()
            }
        }
    }
}
#Preview {
    ContentView()
}
