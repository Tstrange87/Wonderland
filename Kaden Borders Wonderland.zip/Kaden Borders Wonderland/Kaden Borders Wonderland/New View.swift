//
//  New View.swift
//  Kaden Borders Wonderland
//
//  Created by Kaden Borders on 7/15/25.
//

import SwiftUI

struct NewView: View {
    var body: some View {
        NavigationStack{
            HStack{
                
                ZStack {
                    Color.orange.edgesIgnoringSafeArea(.all)
                    
                    
                    NavigationLink{
                        Self_Portrait()
                    }    label: {
                        Image("Self portrait")
                            .resizable()
                            .frame(width: 100, height: 100)
                        
                    }
                }
            }
            
        }
    }
    #Preview {
        ContentView()
        
    }
}
