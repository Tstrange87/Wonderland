//
//  Self Portrait.swift
//  Kaden Borders Wonderland
//
//  Created by Kaden Borders on 7/22/25.
//

import SwiftUI

struct Self_Portrait: View {
    var body: some View {
        ZStack {
         Rectangle()
                .foregroundStyle(Color.black)
                .frame(width: 280, height:15 )
                .offset(x: 0, y: -140)
            Rectangle()
                   .foregroundStyle(Color.black)
                   .frame(width: 250, height:65 )
                   .offset(x: -15, y: -120)
            Rectangle()
                   .foregroundStyle(Color.black)
                   .frame(width: 250, height:65 )
                   .offset(x: 15, y: -120)
            
            Rectangle()
                .foregroundStyle(Color.brown)
                .frame(width: 270, height: 275)
            Circle()
                .foregroundStyle(Color.white)
                .frame(width: 50, height: 150)
                .offset(x: -50, y: -80)
                Circle()
                .foregroundStyle(Color.white)
                .frame(width: 50, height: 150)
                .offset(x: 50, y: -80)
            Circle()
                .foregroundStyle(Color.black)
                .frame(width: 40, height: 20)
                .offset(x: -50, y: -80)
            Circle()
                .foregroundStyle(Color.black)
                .frame(width: 40, height: 20)
                .offset(x: 50, y: -80)
          Rectangle()
                .foregroundStyle(Color.black)
                .frame(width: 50, height: 15)
                .offset(x: -50, y: -125)
            Rectangle()
                  .foregroundStyle(Color.black)
                  .frame(width: 50, height: 15)
                  .offset(x: 50, y: -110)
            Rectangle()
                  .foregroundStyle(Color.black)
                  .frame(width: 125, height: 15)
                  .offset(x: 1, y: 50)
     RoundedRectangle(cornerRadius: 70)
            .foregroundStyle(Color.gray)
                .frame(width: 200, height: 350)
                .offset(x: 0, y: 350)
        }
    }
}
        #Preview {
            Self_Portrait()
        }
  
